"use client";

import { motion } from "framer-motion";
import { ArrowDownRight, ArrowRight, Clock, Mic, Phone, Star, Video } from "lucide-react";
import { CalendarIcon, DriveIcon, GmailIcon, GoogleG, MeetIcon } from "./icons";
import { EASE, FloatChip } from "./motion";
import { Serif } from "./ui";

const APPS = [
  "Gmail", "Drive", "Meet", "Calendar", "Docs", "Sheets", "Slides",
  "Admin", "Chat", "Forms", "Keep", "Gemini", "Vault", "Sites",
];

const APP_COLORS = ["#EA4335", "#4285F4", "#00AC47", "#4285F4", "#4285F4", "#0F9D58", "#F4B400", "#4285F4", "#00AC47", "#7248B9", "#FBBC04", "#9B72CB", "#0B1220", "#4285F4"];

function Stars({ className = "h-3.5 w-3.5" }: { className?: string }) {
  return (
    <span className="flex gap-[2px]">
      {[...Array(5)].map((_, i) => (
        <Star key={i} className={`${className} fill-g-yellow text-g-yellow`} strokeWidth={1} />
      ))}
    </span>
  );
}

/* ----- CSS-built "workspace window" mock ----- */
function WorkspaceWindow() {
  const rows = [
    { c: "#EA4335", w1: "68%", w2: "42%" },
    { c: "#4285F4", w1: "52%", w2: "61%" },
    { c: "#0F9D58", w1: "74%", w2: "38%" },
    { c: "#F4B400", w1: "47%", w2: "55%" },
  ];
  return (
    <div className="relative w-full overflow-hidden rounded-2xl border border-ink/10 bg-white shadow-[0_24px_60px_-24px_rgba(11,18,32,0.35)]">
      {/* title bar */}
      <div className="flex items-center gap-2 border-b border-ink/8 px-4 py-3">
        <span className="h-2.5 w-2.5 rounded-full bg-g-red" />
        <span className="h-2.5 w-2.5 rounded-full bg-g-yellow" />
        <span className="h-2.5 w-2.5 rounded-full bg-g-green" />
        <span className="ml-3 rounded-md bg-paper px-2.5 py-1 text-[10px] font-medium text-ink-soft">
          workspace.yourcompany.com
        </span>
      </div>
      <div className="grid grid-cols-5">
        {/* inbox side */}
        <div className="col-span-3 border-r border-ink/8 p-4">
          <div className="mb-3 flex items-center gap-2">
            <GmailIcon className="h-4 w-4" />
            <span className="text-[11px] font-semibold text-ink">Inbox — you@yourcompany.com</span>
          </div>
          <div className="space-y-2.5">
            {rows.map((r, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -14 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1 + i * 0.15, duration: 0.6, ease: EASE }}
                className="flex items-center gap-2.5 rounded-xl border border-ink/6 bg-paper/70 p-2.5"
              >
                <span className="h-6 w-6 shrink-0 rounded-full" style={{ background: r.c }} />
                <span className="flex-1 space-y-1.5">
                  <span className="block h-1.5 rounded-full bg-ink/15" style={{ width: r.w1 }} />
                  <span className="block h-1.5 rounded-full bg-ink/8" style={{ width: r.w2 }} />
                </span>
              </motion.div>
            ))}
          </div>
        </div>
        {/* meet side */}
        <div className="col-span-2 flex flex-col p-4">
          <div className="mb-3 flex items-center gap-2">
            <MeetIcon className="h-4 w-4" />
            <span className="text-[11px] font-semibold text-ink">Daily standup</span>
            <span className="ml-auto flex h-1.5 w-1.5">
              <span className="absolute h-1.5 w-1.5 animate-ping rounded-full bg-g-green opacity-75" />
              <span className="h-1.5 w-1.5 rounded-full bg-g-green" />
            </span>
          </div>
          <div className="grid flex-1 grid-cols-2 gap-2">
            {[
              { n: "AR", c: "#4285F4", live: true },
              { n: "FK", c: "#EA4335" },
              { n: "BM", c: "#0F9D58" },
              { n: "HS", c: "#F4B400" },
            ].map((t) => (
              <div
                key={t.n}
                className={`flex items-center justify-center rounded-xl ${t.live ? "ring-2 ring-g-green ring-offset-1" : ""}`}
                style={{ background: `${t.c}1A` }}
              >
                <span
                  className="flex h-7 w-7 items-center justify-center rounded-full text-[10px] font-bold text-white"
                  style={{ background: t.c }}
                >
                  {t.n}
                </span>
              </div>
            ))}
          </div>
          <div className="mt-3 flex items-center justify-center gap-2">
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-paper-2">
              <Mic className="h-3 w-3 text-ink" />
            </span>
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-paper-2">
              <Video className="h-3 w-3 text-ink" />
            </span>
            <span className="flex h-7 w-9 items-center justify-center rounded-full bg-g-red">
              <Phone className="h-3 w-3 rotate-[135deg] text-white" />
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function Hero() {
  return (
    <section id="top" className="glow-hero relative overflow-hidden pt-[136px] sm:pt-[152px]">
      <div className="dot-grid pointer-events-none absolute inset-0 opacity-40 [mask-image:radial-gradient(60rem_40rem_at_50%_0%,black,transparent)]" />
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid items-center gap-14 pb-16 lg:grid-cols-12 lg:gap-8 lg:pb-24">
          {/* ------- copy ------- */}
          <div className="lg:col-span-6">
            <motion.div
              initial={{ opacity: 0, y: 26 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, ease: EASE }}
              className="inline-flex items-center gap-2.5 rounded-full border border-ink/10 bg-white px-4 py-2 shadow-sm"
            >
              <GoogleG className="h-4 w-4" />
              <Stars />
              <span className="text-[13px] font-semibold text-ink">4.7</span>
              <span className="text-[13px] text-ink-soft">— 86 Google reviews</span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 34 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.1, ease: EASE }}
              className="mt-7 font-display text-[clamp(2.9rem,6.4vw,5.4rem)] font-medium leading-[1.0] tracking-[-0.035em] text-ink"
            >
              Work smarter,
              <br />
              <Serif>together.</Serif>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.2, ease: EASE }}
              className="mt-6 max-w-xl text-[17px] leading-relaxed text-ink-soft"
            >
              Google Workspace deployment, migration, training and{" "}
              <span className="font-semibold text-ink">24/7 local support</span> for Pakistani
              businesses — set up by Lahore&apos;s top-rated Workspace team, billed in PKR, live in
              as little as 48 hours.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 26 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.9, delay: 0.3, ease: EASE }}
              className="mt-9 flex flex-wrap items-center gap-3.5"
            >
              <a
                href="#contact"
                className="group inline-flex items-center gap-2.5 rounded-full bg-ink px-7 py-4 text-[15px] font-semibold text-white transition-all hover:scale-[1.03] hover:shadow-xl hover:shadow-ink/20"
              >
                Get a free quote
                <ArrowRight className="h-4.5 w-4.5 transition-transform group-hover:translate-x-1" />
              </a>
              <a
                href="#pricing"
                className="group inline-flex items-center gap-2.5 rounded-full border border-ink/15 bg-white/60 px-7 py-4 text-[15px] font-semibold text-ink backdrop-blur transition-all hover:border-ink/35"
              >
                See pricing
                <ArrowDownRight className="h-4.5 w-4.5 transition-transform group-hover:translate-y-0.5" />
              </a>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 1, delay: 0.5 }}
              className="mt-10 flex flex-wrap items-center gap-x-6 gap-y-2.5 text-[13.5px] text-ink-soft"
            >
              <span className="inline-flex items-center gap-2">
                <Clock className="h-4 w-4 text-g-green" />
                <span className="font-semibold text-ink">Open 24 hours</span> — every day
              </span>
              <span className="hidden h-1 w-1 rounded-full bg-ink/25 sm:block" />
              <span>Johar Town, Lahore</span>
              <span className="hidden h-1 w-1 rounded-full bg-ink/25 sm:block" />
              <span>Serving all of Pakistan</span>
            </motion.div>
          </div>

          {/* ------- visual ------- */}
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 1.1, delay: 0.25, ease: EASE }}
            className="relative lg:col-span-6"
          >
            <div className="relative rounded-[2rem] border border-ink/8 bg-gradient-to-br from-white via-paper to-white p-3.5 shadow-[0_40px_90px_-40px_rgba(11,18,32,0.35)] sm:p-6">
              <div
                className="pointer-events-none absolute inset-0 rounded-[2rem] bg-cover bg-center opacity-[0.22]"
                style={{ backgroundImage: "url(/images/hero-abstract.jpg)" }}
              />
              <div className="relative">
                <WorkspaceWindow />
              </div>
            </div>

            <FloatChip
              className="absolute -left-3 top-8 sm:-left-8"
              delay={0.9}
              duration={5.5}
            >
              <div className="flex items-center gap-2.5 rounded-2xl border border-ink/8 bg-white px-4 py-3 shadow-lg shadow-ink/10">
                <DriveIcon className="h-6 w-6" />
                <div>
                  <p className="text-[12px] font-bold text-ink">2 TB Drive</p>
                  <p className="text-[10.5px] text-ink-soft">per user</p>
                </div>
              </div>
            </FloatChip>

            <FloatChip
              className="absolute -right-2 top-[38%] sm:-right-6"
              delay={1.15}
              duration={6.5}
              range={12}
            >
              <div className="flex items-center gap-2.5 rounded-2xl border border-ink/8 bg-white px-4 py-3 shadow-lg shadow-ink/10">
                <CalendarIcon className="h-6 w-6" />
                <div>
                  <p className="text-[12px] font-bold text-ink">Smart scheduling</p>
                  <p className="text-[10.5px] text-ink-soft">across time zones</p>
                </div>
              </div>
            </FloatChip>

            <FloatChip
              className="absolute -bottom-5 left-6 sm:left-10"
              delay={1.4}
              duration={5}
              range={8}
            >
              <div className="flex items-center gap-3 rounded-2xl bg-ink px-4.5 py-3.5 shadow-xl shadow-ink/30">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-g-green">
                  <GoogleG className="h-4 w-4 rounded-full bg-white p-[2px]" />
                </span>
                <div>
                  <p className="text-[12px] font-bold text-white">Migration complete</p>
                  <p className="text-[10.5px] text-white/60">42 users moved — zero downtime</p>
                </div>
              </div>
            </FloatChip>
          </motion.div>
        </div>
      </div>

      {/* ------- marquee ------- */}
      <div className="relative border-y border-ink/8 bg-white/60 py-5 backdrop-blur">
        <div className="marquee-mask overflow-hidden">
          <div className="animate-marquee flex w-max items-center gap-10 pr-10">
            {[...APPS, ...APPS].map((app, i) => (
              <span key={i} className="flex items-center gap-10">
                <span className="font-display text-[15px] font-semibold tracking-wide text-ink/70">
                  {app}
                </span>
                <span
                  className="h-1.5 w-1.5 rounded-full"
                  style={{ background: APP_COLORS[i % APPS.length] }}
                />
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
