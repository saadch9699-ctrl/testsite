"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { ArrowRight, BadgePercent, Check } from "lucide-react";
import { EASE, Reveal } from "./motion";
import { cn, SectionTag, SectionTitle, Serif } from "./ui";

type Plan = {
  name: string;
  tagline: string;
  monthly: number | null;
  annual: number | null;
  popular?: boolean;
  features: string[];
  cta: string;
};

const PLANS: Plan[] = [
  {
    name: "Business Starter",
    tagline: "For small teams going pro",
    monthly: 1199,
    annual: 999,
    features: [
      "Custom email @yourcompany.com",
      "30 GB pooled storage / user",
      "100-participant video meetings",
      "Standard support from our team",
      "Basic admin & security controls",
    ],
    cta: "Start with Starter",
  },
  {
    name: "Business Standard",
    tagline: "The crowd favourite",
    monthly: 2399,
    annual: 1999,
    popular: true,
    features: [
      "Everything in Starter, plus:",
      "2 TB pooled storage / user",
      "150-participant Meet + recording",
      "Shared Drives for your files",
      "Migration assistance included",
      "Priority 24/7 support",
    ],
    cta: "Start with Standard",
  },
  {
    name: "Business Plus",
    tagline: "For compliance-minded teams",
    monthly: 3999,
    annual: 3499,
    features: [
      "Everything in Standard, plus:",
      "5 TB pooled storage / user",
      "500-participant Meet + attendance",
      "Google Vault eDiscovery",
      "Advanced endpoint management",
      "Dedicated onboarding engineer",
    ],
    cta: "Start with Plus",
  },
  {
    name: "Enterprise",
    tagline: "For scale & strict security",
    monthly: null,
    annual: null,
    features: [
      "Everything in Plus, plus:",
      "Unlimited pooled storage*",
      "1,000-participant Meet + livestream",
      "S/MIME encryption & DLP",
      "Advanced uptime SLA",
      "Named account manager",
    ],
    cta: "Talk to sales",
  },
];

export default function Pricing() {
  const [annual, setAnnual] = useState(true);

  return (
    <section id="pricing" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <Reveal>
            <SectionTag>Pricing</SectionTag>
          </Reveal>
          <Reveal delay={0.08}>
            <SectionTitle className="mt-6">
              Honest PKR pricing.
              <br />
              No <Serif>dollar shocks.</Serif>
            </SectionTitle>
          </Reveal>
          <Reveal delay={0.16}>
            <p className="mt-5 text-[15.5px] leading-relaxed text-ink-soft">
              Local invoicing, bank transfer or card — you never need an international payment
              method. Per user, per month.
            </p>
          </Reveal>

          {/* toggle */}
          <Reveal delay={0.2}>
            <div className="mt-8 inline-flex items-center rounded-full border border-ink/10 bg-white p-1.5 shadow-sm">
              {(["Monthly", "Annual"] as const).map((mode) => {
                const active = (mode === "Annual") === annual;
                return (
                  <button
                    key={mode}
                    onClick={() => setAnnual(mode === "Annual")}
                    className={cn(
                      "relative rounded-full px-6 py-2.5 text-[13.5px] font-semibold transition-colors",
                      active ? "text-white" : "text-ink-soft hover:text-ink"
                    )}
                  >
                    {active && (
                      <motion.span
                        layoutId="billing-pill"
                        className="absolute inset-0 rounded-full bg-ink"
                        transition={{ duration: 0.45, ease: EASE }}
                      />
                    )}
                    <span className="relative flex items-center gap-1.5">
                      {mode}
                      {mode === "Annual" && (
                        <span className={cn("text-[10.5px] font-bold", active ? "text-g-yellow" : "text-g-green")}>
                          −17%
                        </span>
                      )}
                    </span>
                  </button>
                );
              })}
            </div>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          {PLANS.map((p, i) => {
            const price = annual ? p.annual : p.monthly;
            const dark = p.popular;
            return (
              <Reveal key={p.name} delay={i * 0.07} className="h-full">
                <div
                  className={cn(
                    "relative flex h-full flex-col rounded-[1.75rem] border p-7 transition-all duration-500 hover:-translate-y-1.5 sm:p-8",
                    dark
                      ? "glow-dark border-transparent bg-ink text-white shadow-2xl shadow-ink/30 hover:shadow-[0_36px_70px_-28px_rgba(11,18,32,0.7)]"
                      : "border-ink/8 bg-card hover:border-ink/20 hover:shadow-[0_28px_55px_-28px_rgba(11,18,32,0.3)]"
                  )}
                >
                  {dark && (
                    <span className="absolute -top-3.5 left-1/2 flex -translate-x-1/2 items-center gap-1.5 whitespace-nowrap rounded-full bg-g-yellow px-4 py-1.5 text-[11px] font-bold text-ink shadow-lg">
                      <BadgePercent className="h-3.5 w-3.5" /> MOST POPULAR
                    </span>
                  )}

                  <h3 className={cn("font-display text-[19px] font-semibold tracking-tight", dark ? "text-white" : "text-ink")}>
                    {p.name}
                  </h3>
                  <p className={cn("mt-1 text-[13px]", dark ? "text-white/55" : "text-ink-soft")}>
                    {p.tagline}
                  </p>

                  <div className="mt-6 flex items-end gap-1.5">
                    {price ? (
                      <>
                        <span className={cn("text-[13px] font-semibold", dark ? "text-white/60" : "text-ink-soft")}>
                          PKR
                        </span>
                        <span
                          className={cn(
                            "font-display text-[2.6rem] font-medium leading-none tracking-tight",
                            dark ? "text-white" : "text-ink"
                          )}
                        >
                          {price.toLocaleString()}
                        </span>
                        <span className={cn("pb-1 text-[12px]", dark ? "text-white/50" : "text-ink-soft")}>
                          /user/mo
                        </span>
                      </>
                    ) : (
                      <span
                        className={cn(
                          "font-display text-[2.2rem] font-medium leading-none tracking-tight",
                          dark ? "text-white" : "text-ink"
                        )}
                      >
                        Let&apos;s talk
                      </span>
                    )}
                  </div>
                  {price && (
                    <p className={cn("mt-1.5 text-[11.5px]", dark ? "text-white/45" : "text-ink-soft/80")}>
                      {annual ? "Billed annually · 2 months free" : "Billed monthly · switch anytime"}
                    </p>
                  )}

                  <ul className={cn("mt-7 flex-1 space-y-3 border-t pt-6", dark ? "border-white/10" : "border-ink/8")}>
                    {p.features.map((f) => (
                      <li key={f} className="flex items-start gap-2.5 text-[13.5px] leading-snug">
                        <span
                          className={cn(
                            "mt-0.5 flex h-4.5 w-4.5 shrink-0 items-center justify-center rounded-full",
                            dark ? "bg-g-green/20" : "bg-g-green/12"
                          )}
                        >
                          <Check className="h-3 w-3 text-g-green" strokeWidth={3} />
                        </span>
                        <span className={dark ? "text-white/75" : "text-ink-soft"}>{f}</span>
                      </li>
                    ))}
                  </ul>

                  <a
                    href={`/?plan=${encodeURIComponent(p.name)}#contact`}
                    className={cn(
                      "group mt-8 flex items-center justify-center gap-2 rounded-full py-3.5 text-[14px] font-semibold transition-all",
                      dark
                        ? "bg-white text-ink hover:scale-[1.02]"
                        : "border border-ink/15 text-ink hover:border-ink hover:bg-ink hover:text-white"
                    )}
                  >
                    {p.cta}
                    <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </a>
                </div>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={0.2}>
          <p className="mt-8 text-center text-[12.5px] text-ink-soft/80">
            *Storage varies by Enterprise agreement. Prices exclude 16% GST. Nonprofits &amp;
            educational institutions — ask about discounted Workspace for Education licensing.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
