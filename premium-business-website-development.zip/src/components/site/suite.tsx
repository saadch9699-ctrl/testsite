"use client";

import { ArrowUpRight, AtSign, Files, Lock, ShieldCheck, Video, Sparkles } from "lucide-react";
import {
  AdminIcon,
  ChatIcon,
  DocsIcon,
  DriveIcon,
  FormsIcon,
  GeminiIcon,
  GmailIcon,
  KeepIcon,
  MeetIcon,
  SheetsIcon,
  SlidesIcon,
} from "./icons";
import { Reveal } from "./motion";
import { SectionTag, SectionTitle, Serif } from "./ui";

const trio = [
  { Icon: DocsIcon, name: "Docs", color: "#4285F4" },
  { Icon: SheetsIcon, name: "Sheets", color: "#0F9D58" },
  { Icon: SlidesIcon, name: "Slides", color: "#F4B400" },
  { Icon: FormsIcon, name: "Forms", color: "#7248B9" },
  { Icon: KeepIcon, name: "Keep", color: "#FBBC04" },
  { Icon: ChatIcon, name: "Chat", color: "#00AC47" },
];

export default function Suite() {
  return (
    <section id="suite" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <Reveal>
          <SectionTag>The Suite</SectionTag>
        </Reveal>
        <div className="mt-6 flex flex-wrap items-end justify-between gap-6">
          <Reveal delay={0.08}>
            <SectionTitle>
              One subscription.
              <br />
              Every app your <Serif>team lives in.</Serif>
            </SectionTitle>
          </Reveal>
          <Reveal delay={0.16} className="max-w-md">
            <p className="text-[15.5px] leading-relaxed text-ink-soft">
              Not fourteen vendors. Not fourteen bills. Just Google&apos;s business-critical apps —
              wired together, secured and supported by one team in Lahore.
            </p>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-4 lg:grid-cols-12">
          {/* Gmail — large */}
          <Reveal className="lg:col-span-7" delay={0.05}>
            <div className="group relative h-full overflow-hidden rounded-[1.75rem] border border-ink/8 bg-card p-8 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_30px_60px_-30px_rgba(234,67,53,0.3)] sm:p-10">
              <div className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-g-red/8 blur-2xl transition-transform duration-700 group-hover:scale-150" />
              <div className="relative">
                <div className="flex items-start justify-between">
                  <GmailIcon className="h-11 w-11" />
                  <ArrowUpRight className="h-5 w-5 text-ink/25 transition-all duration-300 group-hover:translate-x-1 group-hover:-translate-y-1 group-hover:text-g-red" />
                </div>
                <h3 className="mt-6 font-display text-2xl font-medium tracking-tight text-ink sm:text-[1.7rem]">
                  Email that means business
                </h3>
                <p className="mt-2.5 max-w-md text-[15px] leading-relaxed text-ink-soft">
                  Ditch the free address. Get <span className="font-semibold text-ink">you@yourcompany.com</span>{" "}
                  on the world&apos;s most reliable mail platform — with 99.9% uptime.
                </p>
                <div className="mt-7 flex flex-wrap items-center gap-3">
                  <div className="flex items-center gap-2.5 rounded-xl border border-ink/10 bg-paper px-4 py-3 font-mono text-[13px] text-ink-soft">
                    <AtSign className="h-4 w-4 text-g-red" />
                    ayesha<span className="text-ink/30">@</span>
                    <span className="font-semibold text-ink">yourcompany.com</span>
                    <span className="ml-1 inline-block h-3.5 w-[2px] animate-pulse bg-g-red" />
                  </div>
                  <span className="rounded-full bg-g-red/10 px-3.5 py-1.5 text-[12px] font-semibold text-g-red">
                    Replaces @gmail.com
                  </span>
                </div>
              </div>
            </div>
          </Reveal>

          {/* Meet */}
          <Reveal className="lg:col-span-5" delay={0.12}>
            <div className="group relative h-full overflow-hidden rounded-[1.75rem] border border-ink/8 bg-card p-8 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_30px_60px_-30px_rgba(0,172,71,0.3)] sm:p-10">
              <div className="absolute -left-12 -bottom-12 h-48 w-48 rounded-full bg-g-green/10 blur-2xl transition-transform duration-700 group-hover:scale-150" />
              <div className="relative">
                <div className="flex items-start justify-between">
                  <MeetIcon className="h-11 w-11" />
                  <Video className="h-5 w-5 text-ink/25 transition-colors group-hover:text-g-green" />
                </div>
                <h3 className="mt-6 font-display text-2xl font-medium tracking-tight text-ink">
                  Meetings without the mayhem
                </h3>
                <p className="mt-2.5 text-[15px] leading-relaxed text-ink-soft">
                  Meet with up to 500 participants, record to Drive, live captions — no downloads,
                  works on any connection from Karachi to Gilgit.
                </p>
                <div className="mt-7 flex gap-2">
                  {["#4285F4", "#EA4335", "#0F9D58", "#F4B400"].map((c, i) => (
                    <span
                      key={c}
                      className="flex h-11 w-11 items-center justify-center rounded-2xl text-[11px] font-bold text-white transition-transform duration-300 group-hover:scale-110"
                      style={{ background: c, transitionDelay: `${i * 40}ms` }}
                    >
                      {["S", "I", "S", "I"][i]}
                    </span>
                  ))}
                  <span className="flex h-11 items-center rounded-2xl bg-ink/5 px-3.5 text-[12px] font-semibold text-ink-soft">
                    +146 more
                  </span>
                </div>
              </div>
            </div>
          </Reveal>

          {/* Drive */}
          <Reveal className="lg:col-span-4" delay={0.05}>
            <div className="group h-full rounded-[1.75rem] border border-ink/8 bg-card p-8 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_30px_60px_-30px_rgba(66,133,244,0.3)]">
              <div className="flex items-start justify-between">
                <DriveIcon className="h-10 w-10" />
                <Files className="h-5 w-5 text-ink/25 transition-colors group-hover:text-g-blue" />
              </div>
              <h3 className="mt-5 font-display text-xl font-medium tracking-tight text-ink">
                A file server that never sleeps
              </h3>
              <p className="mt-2 text-[14.5px] leading-relaxed text-ink-soft">
                Shared Drives replace your office NAS. Access anywhere, version everything.
              </p>
              <div className="mt-6">
                <div className="flex h-3 overflow-hidden rounded-full">
                  <span className="w-[38%] bg-g-blue" />
                  <span className="w-[27%] bg-g-red" />
                  <span className="w-[22%] bg-g-yellow" />
                  <span className="w-[13%] bg-g-green" />
                </div>
                <div className="mt-2.5 flex justify-between text-[11.5px] font-medium text-ink-soft">
                  <span>2 TB pooled storage / user</span>
                  <span className="text-g-green font-semibold">Unlimited on Enterprise</span>
                </div>
              </div>
            </div>
          </Reveal>

          {/* Docs trio */}
          <Reveal className="lg:col-span-8" delay={0.12}>
            <div className="group h-full overflow-hidden rounded-[1.75rem] border border-ink/8 bg-card p-8 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_30px_60px_-30px_rgba(11,18,32,0.25)] sm:p-10">
              <h3 className="font-display text-xl font-medium tracking-tight text-ink sm:text-2xl">
                Create together, in real time
              </h3>
              <p className="mt-2 max-w-lg text-[14.5px] leading-relaxed text-ink-soft">
                Docs, Sheets, Slides, Forms, Keep &amp; Chat — fifty cursors in one document, zero
                &quot;final_v7_FINAL.xlsx&quot; attachments ever again.
              </p>
              <div className="mt-7 grid grid-cols-3 gap-3 sm:grid-cols-6">
                {trio.map(({ Icon, name }, i) => (
                  <div
                    key={name}
                    className="flex flex-col items-center gap-2 rounded-2xl border border-ink/6 bg-paper/60 py-4 transition-all duration-300 hover:-translate-y-1.5 hover:border-ink/15 hover:bg-white"
                    style={{ transitionDelay: `${i * 30}ms` }}
                  >
                    <Icon className="h-8 w-8" />
                    <span className="text-[11px] font-semibold text-ink-soft">{name}</span>
                  </div>
                ))}
              </div>
            </div>
          </Reveal>

          {/* Admin dark cell */}
          <Reveal className="lg:col-span-7" delay={0.05} y={40}>
            <div className="glow-dark group relative h-full overflow-hidden rounded-[1.75rem] bg-ink p-8 text-white transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_30px_60px_-25px_rgba(11,18,32,0.7)] sm:p-10">
              <div className="relative">
                <div className="flex items-start justify-between">
                  <AdminIcon className="h-11 w-11" />
                  <ShieldCheck className="h-5 w-5 text-white/30 transition-colors group-hover:text-g-blue" />
                </div>
                <h3 className="mt-6 font-display text-2xl font-medium tracking-tight">
                  Enterprise-grade control, admin-simple
                </h3>
                <p className="mt-2.5 max-w-md text-[15px] leading-relaxed text-white/60">
                  Admin console, Vault eDiscovery, endpoint management and 2-step verification —
                  configured for you on day one.
                </p>
                <div className="mt-8 grid grid-cols-3 gap-3">
                  {[
                    { v: "99.9%", l: "uptime SLA" },
                    { v: "256-bit", l: "encryption" },
                    { v: "2FA", l: "enforced" },
                  ].map((s) => (
                    <div key={s.l} className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3.5">
                      <p className="font-display text-lg font-semibold">{s.v}</p>
                      <p className="text-[11.5px] text-white/50">{s.l}</p>
                    </div>
                  ))}
                </div>
              </div>
              <Lock className="absolute -bottom-10 -right-10 h-44 w-44 text-white/[0.04] transition-transform duration-700 group-hover:rotate-6" />
            </div>
          </Reveal>

          {/* Gemini cell */}
          <Reveal className="lg:col-span-5" delay={0.12} y={40}>
            <div className="group relative h-full overflow-hidden rounded-[1.75rem] border border-transparent bg-gradient-to-br from-[#3E8FF5] via-[#6f7bd8] to-[#9B72CB] p-8 text-white transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_30px_60px_-25px_rgba(151,114,203,0.6)] sm:p-10">
              <div className="relative">
                <div className="flex items-start justify-between">
                  <GeminiIcon className="h-11 w-11 brightness-0 invert" />
                  <Sparkles className="h-5 w-5 text-white/50" />
                </div>
                <h3 className="mt-6 font-display text-2xl font-medium tracking-tight">
                  Gemini AI, built into every app
                </h3>
                <p className="mt-2.5 text-[15px] leading-relaxed text-white/75">
                  Draft emails, summarize meetings, build sheets formulas — ask us which AI add-on
                  actually pays for itself.
                </p>
                <div className="mt-7 flex flex-wrap gap-2">
                  {["“Summarize this thread”", "“Draft a proposal”", "“Fix my formula”"].map((p) => (
                    <span
                      key={p}
                      className="rounded-full border border-white/25 bg-white/10 px-3.5 py-1.5 text-[12px] font-medium backdrop-blur"
                    >
                      {p}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
