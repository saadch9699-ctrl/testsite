"use client";

import { ArrowRight, CloudCog, GraduationCap, LifeBuoy, Rocket, ShieldCheck } from "lucide-react";
import { Reveal } from "./motion";
import { SectionTag, SectionTitle, Serif } from "./ui";

const SERVICES = [
  {
    n: "01",
    Icon: Rocket,
    title: "Deployment & provisioning",
    desc: "Domains verified, users provisioned, MX records routed. Most teams are sending from @yourcompany.com within 48 hours of signing.",
    tags: ["Same-week go-live", "DNS handled"],
    accent: "#4285F4",
  },
  {
    n: "02",
    Icon: CloudCog,
    title: "Data migration, zero drama",
    desc: "cPanel, Zoho, Microsoft 365, Outlook PSTs or that aging mail server — we move every email, contact, calendar and file without a minute of downtime.",
    tags: ["cPanel / Zoho / M365", "PST imports", "Zero downtime"],
    accent: "#EA4335",
  },
  {
    n: "03",
    Icon: GraduationCap,
    title: "Training & change management",
    desc: "On-site or remote sessions in Urdu and English so your whole team — from CEO to intern — actually uses the tools you're paying for.",
    tags: ["Urdu + English", "Admin bootcamps"],
    accent: "#F4B400",
  },
  {
    n: "04",
    Icon: LifeBuoy,
    title: "24/7 local support",
    desc: "A Lahore-based engineer answers your call or WhatsApp at 3pm — or 3am. No ticket queues, no offshore handoffs, no 'we'll get back to you'.",
    tags: ["Phone & WhatsApp", "Open 24 hours"],
    accent: "#34A853",
  },
  {
    n: "05",
    Icon: ShieldCheck,
    title: "Security & compliance audits",
    desc: "2FA enforcement, sharing policies, Vault retention rules and quarterly health checks — so your data stays yours.",
    tags: ["Vault setup", "DLP policies"],
    accent: "#7248B9",
  },
];

const STATS = [
  { v: "500+", l: "businesses onboarded" },
  { v: "4.7", l: "Google rating · 86 reviews" },
  { v: "48h", l: "typical go-live" },
  { v: "24/7", l: "human support" },
];

export default function Services() {
  return (
    <section id="services" className="relative overflow-hidden bg-paper-2 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-14 lg:grid-cols-12 lg:gap-10">
          {/* left — sticky intro */}
          <div className="lg:col-span-5">
            <div className="lg:sticky lg:top-28">
              <Reveal>
                <SectionTag>What we do</SectionTag>
              </Reveal>
              <Reveal delay={0.08}>
                <SectionTitle className="mt-6">
                  Not just resellers.
                  <br />
                  Your <Serif>Workspace department.</Serif>
                </SectionTitle>
              </Reveal>
              <Reveal delay={0.16}>
                <p className="mt-5 max-w-md text-[15.5px] leading-relaxed text-ink-soft">
                  Buying the licenses is the easy part. We do the part that decides whether your
                  investment works — rollout, migration, training and a human on the phone whenever
                  you need one.
                </p>
              </Reveal>

              <Reveal delay={0.22}>
                <div className="relative mt-9 overflow-hidden rounded-[1.75rem] border border-ink/10 shadow-xl shadow-ink/10">
                  <img
                    src="https://images.pexels.com/photos/3865639/pexels-photo-3865639.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
                    alt="Team collaborating on Google Workspace"
                    loading="lazy"
                    className="h-64 w-full object-cover transition-transform duration-700 hover:scale-105"
                  />
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-ink/85 to-transparent p-5 pt-14">
                    <p className="font-display text-[15px] font-medium text-white">
                      &ldquo;2am panics, answered by real engineers.&rdquo;
                    </p>
                    <p className="text-[12px] text-white/60">The gworkspace.pk promise</p>
                  </div>
                  <span className="absolute left-4 top-4 rounded-full bg-white/90 px-3.5 py-1.5 text-[11px] font-bold text-ink backdrop-blur">
                    Lahore HQ · Open 24 hours
                  </span>
                </div>
              </Reveal>

              <Reveal delay={0.28}>
                <a
                  href="#contact"
                  className="group mt-8 inline-flex items-center gap-2 font-display text-[15px] font-semibold text-ink"
                >
                  Talk to an engineer today
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-ink text-white transition-transform group-hover:translate-x-1">
                    <ArrowRight className="h-4 w-4" />
                  </span>
                </a>
              </Reveal>
            </div>
          </div>

          {/* right — service rows */}
          <div className="lg:col-span-7">
            <div className="space-y-4">
              {SERVICES.map((s, i) => (
                <Reveal key={s.n} delay={i * 0.06}>
                  <div className="group relative overflow-hidden rounded-[1.5rem] border border-ink/8 bg-card p-6 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_24px_50px_-24px_rgba(11,18,32,0.25)] sm:p-8">
                    <span
                      className="absolute inset-y-0 left-0 w-1 opacity-0 transition-opacity duration-300 group-hover:opacity-100"
                      style={{ background: s.accent }}
                    />
                    <div className="flex items-start gap-5">
                      <span
                        className="hidden h-12 w-12 shrink-0 items-center justify-center rounded-2xl sm:flex"
                        style={{ background: `${s.accent}14` }}
                      >
                        <s.Icon className="h-5.5 w-5.5" style={{ color: s.accent }} />
                      </span>
                      <div className="flex-1">
                        <div className="flex items-baseline justify-between gap-4">
                          <h3 className="font-display text-[19px] font-medium tracking-tight text-ink sm:text-xl">
                            {s.title}
                          </h3>
                          <span className="font-display text-sm font-semibold text-ink/20 transition-colors group-hover:text-ink/40">
                            {s.n}
                          </span>
                        </div>
                        <p className="mt-2 text-[14.5px] leading-relaxed text-ink-soft">{s.desc}</p>
                        <div className="mt-4 flex flex-wrap gap-2">
                          {s.tags.map((t) => (
                            <span
                              key={t}
                              className="rounded-full border border-ink/8 bg-paper px-3 py-1 text-[11.5px] font-semibold text-ink-soft"
                            >
                              {t}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>

        {/* stats band */}
        <Reveal delay={0.1} y={40}>
          <div className="mt-20 grid grid-cols-2 overflow-hidden rounded-[1.75rem] border border-ink/8 bg-card lg:grid-cols-4">
            {STATS.map((s, i) => (
              <div
                key={s.l}
                className={`p-8 text-center sm:p-10 ${i !== 0 ? "border-l border-ink/6" : ""} ${i >= 2 ? "border-t border-ink/6 lg:border-t-0" : ""}`}
              >
                <p className="font-display text-4xl font-medium tracking-tight text-ink sm:text-5xl">
                  {s.v}
                </p>
                <p className="mt-2 text-[13px] font-medium text-ink-soft">{s.l}</p>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
