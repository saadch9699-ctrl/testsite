import type { ReactNode } from "react";

export function cn(...cls: Array<string | false | null | undefined>) {
  return cls.filter(Boolean).join(" ");
}

export function SectionTag({ children, dark = false }: { children: ReactNode; dark?: boolean }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 rounded-full border px-4 py-1.5 text-[11px] font-semibold uppercase tracking-[0.18em]",
        dark ? "border-white/15 bg-white/5 text-white/70" : "border-ink/10 bg-white text-ink-soft"
      )}
    >
      <span className="flex gap-[3px]">
        <i className="h-1.5 w-1.5 rounded-full bg-g-blue" />
        <i className="h-1.5 w-1.5 rounded-full bg-g-red" />
        <i className="h-1.5 w-1.5 rounded-full bg-g-yellow" />
        <i className="h-1.5 w-1.5 rounded-full bg-g-green" />
      </span>
      {children}
    </span>
  );
}

export function SectionTitle({
  children,
  dark = false,
  className,
}: {
  children: ReactNode;
  dark?: boolean;
  className?: string;
}) {
  return (
    <h2
      className={cn(
        "font-display text-[clamp(2.1rem,4.6vw,3.6rem)] font-medium leading-[1.05] tracking-[-0.03em]",
        dark ? "text-white" : "text-ink",
        className
      )}
    >
      {children}
    </h2>
  );
}

export function Serif({ children }: { children: ReactNode }) {
  return <em className="font-serif italic font-normal">{children}</em>;
}
