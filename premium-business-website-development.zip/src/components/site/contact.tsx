"use client";

import { useEffect, useState, type FormEvent } from "react";
import { useSearchParams } from "next/navigation";
import { motion } from "framer-motion";
import {
  ArrowRight,
  CheckCircle2,
  Clock,
  Globe,
  Loader2,
  MapPin,
  MessageCircle,
  Phone,
} from "lucide-react";
import { EASE, Reveal } from "./motion";
import { SectionTag, SectionTitle, Serif } from "./ui";

const PLANS = ["Business Starter", "Business Standard", "Business Plus", "Enterprise", "Not sure yet — advise me"];

type Status = "idle" | "sending" | "success" | "error";

const INFO = [
  {
    Icon: MapPin,
    label: "Visit us",
    value: "83-F, Block F, Phase 1, Johar Town, Lahore 54600",
    href: "https://www.google.com/maps/search/83-F+Block+F+Phase+1+Johar+Town+Lahore",
  },
  {
    Icon: Phone,
    label: "Call us — anytime",
    value: "0311 1222735",
    href: "tel:+923111222735",
  },
  {
    Icon: MessageCircle,
    label: "WhatsApp",
    value: "+92 311 1222735",
    href: "https://wa.me/923111222735",
  },
  {
    Icon: Globe,
    label: "On the web",
    value: "gworkspace.pk",
    href: "https://gworkspace.pk",
  },
  {
    Icon: Clock,
    label: "Hours",
    value: "Open 24 hours — every single day",
    href: undefined,
  },
];

export default function Contact() {
  const params = useSearchParams();
  const [status, setStatus] = useState<Status>("idle");
  const [ticketId, setTicketId] = useState<number | null>(null);
  const [errorMsg, setErrorMsg] = useState("");
  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    company: "",
    plan: "Not sure yet — advise me",
    message: "",
  });

  useEffect(() => {
    const plan = params.get("plan");
    if (plan && PLANS.includes(plan)) {
      setForm((f) => ({ ...f, plan }));
    }
  }, [params]);

  const set = (k: keyof typeof form) => (e: { target: { value: string } }) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setStatus("sending");
    setErrorMsg("");
    try {
      const res = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (res.ok && data.ok) {
        setTicketId(data.id);
        setStatus("success");
      } else {
        setErrorMsg(data.error ?? "Something went wrong.");
        setStatus("error");
      }
    } catch {
      setErrorMsg("Network error — please check your connection and retry.");
      setStatus("error");
    }
  }

  const inputCls =
    "w-full rounded-xl border border-ink/12 bg-paper/60 px-4 py-3.5 text-[14px] text-ink outline-none transition-all placeholder:text-ink-soft/60 focus:border-g-blue focus:bg-white focus:ring-4 focus:ring-g-blue/15";
  const labelCls = "mb-1.5 block text-[12px] font-semibold uppercase tracking-[0.08em] text-ink-soft";

  return (
    <section id="contact" className="glow-dark relative overflow-hidden bg-ink py-24 text-white sm:py-32">
      <div className="relative mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-14 lg:grid-cols-12 lg:gap-10">
          {/* left — info */}
          <div className="lg:col-span-5">
            <Reveal>
              <SectionTag dark>Get started</SectionTag>
            </Reveal>
            <Reveal delay={0.08}>
              <SectionTitle dark className="mt-6">
                Let&apos;s put your business on <Serif>Workspace.</Serif>
              </SectionTitle>
            </Reveal>
            <Reveal delay={0.16}>
              <p className="mt-5 max-w-md text-[15.5px] leading-relaxed text-white/60">
                Tell us about your team and we&apos;ll prepare a tailored quote — usually within 15
                minutes, because we never close.
              </p>
            </Reveal>

            <Reveal delay={0.22}>
              <ul className="mt-9 space-y-2">
                {INFO.map(({ Icon, label, value, href }) => (
                  <li key={label}>
                    {href ? (
                      <a
                        href={href}
                        target={href.startsWith("http") ? "_blank" : undefined}
                        rel="noreferrer"
                        className="group flex items-center gap-4 rounded-2xl border border-transparent px-4 py-3.5 transition-all hover:border-white/10 hover:bg-white/5"
                      >
                        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/5">
                          <Icon className="h-4.5 w-4.5 text-g-green" />
                        </span>
                        <span>
                          <span className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-white/40">
                            {label}
                          </span>
                          <span className="block text-[14.5px] font-medium text-white/90 group-hover:text-white">
                            {value}
                          </span>
                        </span>
                      </a>
                    ) : (
                      <div className="flex items-center gap-4 px-4 py-3.5">
                        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-white/10 bg-white/5">
                          <Icon className="h-4.5 w-4.5 text-g-green" />
                        </span>
                        <span>
                          <span className="block text-[11px] font-semibold uppercase tracking-[0.14em] text-white/40">
                            {label}
                          </span>
                          <span className="block text-[14.5px] font-medium text-white/90">{value}</span>
                        </span>
                      </div>
                    )}
                  </li>
                ))}
              </ul>
            </Reveal>

            <Reveal delay={0.28}>
              <div className="mt-8 overflow-hidden rounded-[1.75rem] border border-white/10">
                <iframe
                  title="gworkspace.pk — 83-F Block F, Phase 1, Johar Town, Lahore"
                  src="https://www.google.com/maps?q=83-F%20Block%20F%20Phase%201%20Johar%20Town%20Lahore&output=embed"
                  className="h-56 w-full grayscale-[35%] contrast-[1.05]"
                  loading="lazy"
                />
                <div className="flex items-center justify-between bg-white/5 px-5 py-3.5">
                  <span className="text-[12.5px] text-white/60">Johar Town, Lahore</span>
                  <a
                    href="https://www.google.com/maps/search/83-F+Block+F+Phase+1+Johar+Town+Lahore"
                    target="_blank"
                    rel="noreferrer"
                    className="text-[12.5px] font-semibold text-g-blue hover:underline"
                  >
                    Get directions
                  </a>
                </div>
              </div>
            </Reveal>
          </div>

          {/* right — form */}
          <div className="lg:col-span-7">
            <Reveal delay={0.12} y={44}>
              <div className="relative overflow-hidden rounded-[2rem] bg-card p-7 text-ink shadow-2xl shadow-black/40 sm:p-10">
                <div className="absolute inset-x-0 top-0 h-1.5 bg-gradient-to-r from-g-blue via-g-red to-g-yellow" />
                {status === "success" ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.96 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.6, ease: EASE }}
                    className="flex min-h-[480px] flex-col items-center justify-center text-center"
                  >
                    <span className="flex h-20 w-20 items-center justify-center rounded-full bg-g-green/12">
                      <CheckCircle2 className="h-10 w-10 text-g-green" />
                    </span>
                    <h3 className="mt-7 font-display text-3xl font-medium tracking-tight">
                      Request received.
                    </h3>
                    <p className="mt-3 max-w-md text-[15px] leading-relaxed text-ink-soft">
                      Thank you, <span className="font-semibold text-ink">{form.name.split(" ")[0]}</span>.
                      Your reference is{" "}
                      <span className="rounded-md bg-paper px-2 py-0.5 font-mono text-[13px] font-semibold text-ink">
                        GW-{String(ticketId).padStart(4, "0")}
                      </span>
                      . An engineer will call you within 15 minutes — yes, even at midnight.
                    </p>
                    <div className="mt-8 flex flex-wrap justify-center gap-3">
                      <a
                        href="https://wa.me/923111222735"
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-2 rounded-full bg-ink px-6 py-3 text-[14px] font-semibold text-white transition-transform hover:scale-[1.03]"
                      >
                        <MessageCircle className="h-4 w-4" /> WhatsApp us now
                      </a>
                      <button
                        onClick={() => {
                          setStatus("idle");
                          setForm({ name: "", email: "", phone: "", company: "", plan: "Not sure yet — advise me", message: "" });
                        }}
                        className="rounded-full border border-ink/15 px-6 py-3 text-[14px] font-semibold text-ink transition-colors hover:border-ink/40"
                      >
                        Send another request
                      </button>
                    </div>
                  </motion.div>
                ) : (
                  <>
                    <h3 className="font-display text-2xl font-medium tracking-tight sm:text-[1.7rem]">
                      Request a free quote
                    </h3>
                    <p className="mt-1.5 text-[13.5px] text-ink-soft">
                      No obligation, no spam — just a clear plan and PKR pricing.
                    </p>

                    <form onSubmit={onSubmit} className="mt-8 grid gap-5 sm:grid-cols-2">
                      <div>
                        <label className={labelCls} htmlFor="f-name">Full name *</label>
                        <input
                          id="f-name"
                          required
                          minLength={2}
                          value={form.name}
                          onChange={set("name")}
                          placeholder="Ahmed Raza"
                          className={inputCls}
                        />
                      </div>
                      <div>
                        <label className={labelCls} htmlFor="f-email">Work email *</label>
                        <input
                          id="f-email"
                          type="email"
                          required
                          value={form.email}
                          onChange={set("email")}
                          placeholder="you@currentmail.com"
                          className={inputCls}
                        />
                      </div>
                      <div>
                        <label className={labelCls} htmlFor="f-phone">Phone / WhatsApp</label>
                        <input
                          id="f-phone"
                          value={form.phone}
                          onChange={set("phone")}
                          placeholder="03xx xxxxxxx"
                          className={inputCls}
                        />
                      </div>
                      <div>
                        <label className={labelCls} htmlFor="f-company">Company</label>
                        <input
                          id="f-company"
                          value={form.company}
                          onChange={set("company")}
                          placeholder="Your Company (Pvt) Ltd"
                          className={inputCls}
                        />
                      </div>
                      <div className="sm:col-span-2">
                        <label className={labelCls} htmlFor="f-plan">Plan of interest</label>
                        <select id="f-plan" value={form.plan} onChange={set("plan")} className={inputCls}>
                          {PLANS.map((p) => (
                            <option key={p}>{p}</option>
                          ))}
                        </select>
                      </div>
                      <div className="sm:col-span-2">
                        <label className={labelCls} htmlFor="f-msg">Anything else?</label>
                        <textarea
                          id="f-msg"
                          rows={4}
                          value={form.message}
                          onChange={set("message")}
                          placeholder="Team size, current email setup, deadlines…"
                          className={`${inputCls} resize-none`}
                        />
                      </div>

                      {status === "error" && (
                        <p className="sm:col-span-2 rounded-xl border border-g-red/25 bg-g-red/8 px-4 py-3 text-[13px] font-medium text-g-red">
                          {errorMsg}
                        </p>
                      )}

                      <div className="sm:col-span-2 flex flex-wrap items-center gap-4">
                        <button
                          type="submit"
                          disabled={status === "sending"}
                          className="group inline-flex items-center gap-2.5 rounded-full bg-ink px-8 py-4 text-[15px] font-semibold text-white transition-all hover:scale-[1.03] hover:shadow-xl hover:shadow-ink/20 disabled:cursor-not-allowed disabled:opacity-60"
                        >
                          {status === "sending" ? (
                            <>
                              <Loader2 className="h-4.5 w-4.5 animate-spin" /> Sending…
                            </>
                          ) : (
                            <>
                              Request my quote
                              <ArrowRight className="h-4.5 w-4.5 transition-transform group-hover:translate-x-1" />
                            </>
                          )}
                        </button>
                        <p className="text-[12px] leading-snug text-ink-soft/80">
                          Typical response: <span className="font-semibold text-ink">under 15 minutes</span>
                          <br /> — 24 hours a day, 7 days a week.
                        </p>
                      </div>
                    </form>
                  </>
                )}
              </div>
            </Reveal>
          </div>
        </div>
      </div>
    </section>
  );
}
