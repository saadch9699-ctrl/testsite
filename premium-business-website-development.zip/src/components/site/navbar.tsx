"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowUpRight, Menu, Phone, X } from "lucide-react";
import { LogoMark } from "./icons";
import { cn } from "./ui";

const LINKS = [
  { label: "Suite", href: "#suite" },
  { label: "Services", href: "#services" },
  { label: "Pricing", href: "#pricing" },
  { label: "Reviews", href: "#reviews" },
  { label: "FAQ", href: "#faq" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <motion.header
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-all duration-500",
          scrolled
            ? "border-b border-ink/8 bg-paper/85 backdrop-blur-xl"
            : "border-b border-transparent bg-transparent"
        )}
      >
        <div className="mx-auto flex h-[72px] max-w-7xl items-center justify-between px-5 sm:px-8">
          <a href="#top" className="group flex items-center gap-2.5">
            <LogoMark className="h-7 w-7 transition-transform duration-500 group-hover:rotate-90" />
            <span className="font-display text-[19px] font-semibold tracking-tight text-ink">
              gworkspace<span className="text-g-blue">.pk</span>
            </span>
          </a>

          <nav className="hidden items-center gap-1 lg:flex">
            {LINKS.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="rounded-full px-4 py-2 text-[14px] font-medium text-ink-soft transition-colors hover:bg-ink/5 hover:text-ink"
              >
                {l.label}
              </a>
            ))}
          </nav>

          <div className="flex items-center gap-2.5">
            <a
              href="tel:+923111222735"
              className="hidden items-center gap-2 rounded-full border border-ink/10 bg-white px-4 py-2 text-[13.5px] font-semibold text-ink transition-all hover:border-ink/25 md:flex"
            >
              <Phone className="h-3.5 w-3.5 text-g-green" />
              0311 1222735
            </a>
            <a
              href="#contact"
              className="group hidden items-center gap-1.5 rounded-full bg-ink px-5 py-2.5 text-[13.5px] font-semibold text-white transition-transform hover:scale-[1.03] sm:flex"
            >
              Get a quote
              <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
            <button
              onClick={() => setOpen(!open)}
              aria-label="Toggle menu"
              className="flex h-10 w-10 items-center justify-center rounded-full border border-ink/10 bg-white text-ink lg:hidden"
            >
              {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>
      </motion.header>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
            className="fixed inset-x-3 top-[80px] z-40 rounded-3xl border border-ink/10 bg-white p-4 shadow-2xl shadow-ink/10 lg:hidden"
          >
            <nav className="flex flex-col">
              {[...LINKS, { label: "Contact", href: "#contact" }].map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="flex items-center justify-between rounded-2xl px-4 py-3.5 font-display text-lg font-medium text-ink transition-colors hover:bg-paper"
                >
                  {l.label}
                  <ArrowUpRight className="h-4 w-4 text-ink-soft" />
                </a>
              ))}
            </nav>
            <a
              href="tel:+923111222735"
              className="mt-2 flex items-center justify-center gap-2 rounded-2xl bg-ink py-3.5 font-semibold text-white"
            >
              <Phone className="h-4 w-4" /> Call 0311 1222735 — open 24/7
            </a>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
