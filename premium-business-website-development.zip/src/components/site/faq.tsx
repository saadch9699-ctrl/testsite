"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Plus } from "lucide-react";
import { EASE, Reveal } from "./motion";
import { cn, SectionTag, SectionTitle, Serif } from "./ui";

const faqs = [
  {
    q: "How fast can my business go live on Google Workspace?",
    a: "For teams under 50 users, we typically complete verification, provisioning and mail routing within 24–48 hours. Larger organizations with complex migrations usually go live within a week — with a clear day-by-day plan shared upfront.",
  },
  {
    q: "Can you migrate our existing emails and files?",
    a: "Yes — that's our specialty. We migrate from cPanel/webmail, Zoho, Microsoft 365, GoDaddy, old Exchange servers and even Outlook PST archives. Migrations run in the background (usually overnight or over a weekend) with zero downtime and a post-migration verification report.",
  },
  {
    q: "Is billing really in PKR? We don't have an international card.",
    a: "Absolutely. You receive a local Pakistani invoice and can pay by bank transfer, card, or wallet. No international payment method, no dollar conversion surprises, and proper documentation for your accounts team.",
  },
  {
    q: "What does the 24/7 support actually cover?",
    a: "Anything Workspace: locked accounts, mail delivery issues, storage problems, Meet glitches, new hire onboarding, security incidents. You call or WhatsApp 0311 1222735 and reach a Lahore-based engineer — at noon or 3am. We genuinely never close.",
  },
  {
    q: "Do you offer Google Workspace for Education or nonprofits?",
    a: "Yes. We help schools, universities and registered nonprofits access Google's discounted (and in some cases free) tiers, then handle verification with Google, deployment and teacher/staff training — in Urdu and English.",
  },
  {
    q: "Can Workspace replace our office file server?",
    a: "Almost always. Shared Drives with granular permissions, Drive for desktop streaming, and 2 TB+ per user cover what most office NAS boxes do — minus the hardware, power cuts and 'server is down' mornings. We'll audit your current setup and tell you honestly if it's a fit.",
  },
];

export default function Faq() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <div className="lg:sticky lg:top-28">
              <Reveal>
                <SectionTag>FAQ</SectionTag>
              </Reveal>
              <Reveal delay={0.08}>
                <SectionTitle className="mt-6">
                  Questions?
                  <br />
                  <Serif>Answered.</Serif>
                </SectionTitle>
              </Reveal>
              <Reveal delay={0.16}>
                <p className="mt-5 max-w-sm text-[15px] leading-relaxed text-ink-soft">
                  Still unsure about something? Call us — a real engineer answers, 24 hours a day.
                </p>
              </Reveal>
              <Reveal delay={0.22}>
                <a
                  href="tel:+923111222735"
                  className="mt-7 inline-flex items-center gap-2.5 rounded-full bg-ink px-6 py-3.5 text-[14px] font-semibold text-white transition-transform hover:scale-[1.03]"
                >
                  Call 0311 1222735
                </a>
              </Reveal>
            </div>
          </div>

          <div className="lg:col-span-8">
            <div className="space-y-3.5">
              {faqs.map((f, i) => {
                const isOpen = open === i;
                return (
                  <Reveal key={f.q} delay={i * 0.05}>
                    <div
                      className={cn(
                        "overflow-hidden rounded-[1.4rem] border transition-all duration-300",
                        isOpen
                          ? "border-ink/15 bg-card shadow-[0_20px_45px_-26px_rgba(11,18,32,0.25)]"
                          : "border-ink/8 bg-card/60 hover:border-ink/20"
                      )}
                    >
                      <button
                        onClick={() => setOpen(isOpen ? null : i)}
                        className="flex w-full items-center justify-between gap-4 px-6 py-5 text-left sm:px-8 sm:py-6"
                      >
                        <span className="font-display text-[16px] font-medium tracking-tight text-ink sm:text-[17.5px]">
                          {f.q}
                        </span>
                        <motion.span
                          animate={{ rotate: isOpen ? 45 : 0 }}
                          transition={{ duration: 0.4, ease: EASE }}
                          className={cn(
                            "flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-colors",
                            isOpen ? "bg-ink text-white" : "bg-ink/5 text-ink"
                          )}
                        >
                          <Plus className="h-4.5 w-4.5" />
                        </motion.span>
                      </button>
                      <AnimatePresence initial={false}>
                        {isOpen && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: "auto", opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.45, ease: EASE }}
                          >
                            <p className="px-6 pb-6 text-[14.5px] leading-relaxed text-ink-soft sm:px-8 sm:pb-7">
                              {f.a}
                            </p>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  </Reveal>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
