import { ArrowUpRight, Clock, MapPin, Phone } from "lucide-react";
import { LogoMark } from "./icons";

const suiteLinks = ["Gmail", "Drive", "Meet", "Calendar", "Docs & Sheets", "Admin & Vault"];
const companyLinks = [
  { label: "The Suite", href: "#suite" },
  { label: "Services", href: "#services" },
  { label: "Pricing", href: "#pricing" },
  { label: "Reviews", href: "#reviews" },
  { label: "FAQ", href: "#faq" },
];

export default function Footer() {
  return (
    <footer className="relative overflow-hidden bg-[#070c16] pb-10 pt-20 text-white">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        {/* big CTA line */}
        <div className="flex flex-wrap items-end justify-between gap-8 border-b border-white/8 pb-14">
          <h2 className="max-w-2xl font-display text-[clamp(2rem,4.5vw,3.4rem)] font-medium leading-[1.05] tracking-[-0.03em]">
            Your competitors are already
            <br />
            on Workspace. <span className="font-serif italic font-normal text-white/60">Catch up.</span>
          </h2>
          <a
            href="#contact"
            className="group inline-flex items-center gap-2.5 rounded-full bg-white px-7 py-4 text-[15px] font-semibold text-ink transition-transform hover:scale-[1.04]"
          >
            Get started today
            <ArrowUpRight className="h-4.5 w-4.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
          </a>
        </div>

        <div className="grid gap-12 py-14 md:grid-cols-12">
          <div className="md:col-span-5">
            <a href="#top" className="flex items-center gap-2.5">
              <LogoMark className="h-7 w-7" />
              <span className="font-display text-[19px] font-semibold tracking-tight">
                gworkspace<span className="text-g-blue">.pk</span>
              </span>
            </a>
            <p className="mt-5 max-w-sm text-[14px] leading-relaxed text-white/50">
              Google Workspace Pakistan — business apps &amp; collaboration tools. Deployment,
              migration, training and 24/7 local support for teams across Pakistan.
            </p>
            <div className="mt-6 space-y-2.5 text-[13.5px] text-white/60">
              <a href="tel:+923111222735" className="flex items-center gap-2.5 transition-colors hover:text-white">
                <Phone className="h-4 w-4 text-g-green" /> 0311 1222735
              </a>
              <a
                href="https://www.google.com/maps/search/83-F+Block+F+Phase+1+Johar+Town+Lahore"
                target="_blank"
                rel="noreferrer"
                className="flex items-start gap-2.5 transition-colors hover:text-white"
              >
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-g-blue" />
                83-F, Block F, Phase 1, Johar Town, Lahore 54600
              </a>
              <p className="flex items-center gap-2.5">
                <Clock className="h-4 w-4 text-g-yellow" />
                <span>
                  Open 24 hours <span className="ml-1.5 rounded-full bg-g-green/15 px-2.5 py-0.5 text-[11px] font-bold text-g-green">ALWAYS OPEN</span>
                </span>
              </p>
            </div>
          </div>

          <div className="md:col-span-2">
            <p className="text-[11.5px] font-bold uppercase tracking-[0.18em] text-white/35">Suite</p>
            <ul className="mt-5 space-y-3">
              {suiteLinks.map((l) => (
                <li key={l}>
                  <a href="#suite" className="text-[13.5px] text-white/60 transition-colors hover:text-white">
                    {l}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-2">
            <p className="text-[11.5px] font-bold uppercase tracking-[0.18em] text-white/35">Company</p>
            <ul className="mt-5 space-y-3">
              {companyLinks.map((l) => (
                <li key={l.href}>
                  <a href={l.href} className="text-[13.5px] text-white/60 transition-colors hover:text-white">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div className="md:col-span-3">
            <p className="text-[11.5px] font-bold uppercase tracking-[0.18em] text-white/35">Cities we serve</p>
            <div className="mt-5 flex flex-wrap gap-2">
              {["Lahore", "Karachi", "Islamabad", "Rawalpindi", "Faisalabad", "Multan", "Peshawar", "Sialkot", "+ remote, nationwide"].map(
                (c) => (
                  <span
                    key={c}
                    className="rounded-full border border-white/10 bg-white/5 px-3.5 py-1.5 text-[12px] text-white/60"
                  >
                    {c}
                  </span>
                )
              )}
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 border-t border-white/8 pt-8">
          <p className="text-[12px] text-white/40">
            © {new Date().getFullYear()} gworkspace.pk — Google Workspace Pakistan. All rights reserved.
          </p>
          <p className="max-w-md text-[11.5px] leading-relaxed text-white/30">
            Google Workspace, Gmail, Drive, Meet and related marks are trademarks of Google LLC.
            gworkspace.pk is an independent business solutions provider.
          </p>
        </div>
      </div>
    </footer>
  );
}
