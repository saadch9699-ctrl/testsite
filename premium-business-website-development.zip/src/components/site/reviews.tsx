"use client";

import { ArrowUpRight, Star } from "lucide-react";
import { GoogleG } from "./icons";
import { Reveal } from "./motion";
import { SectionTag, SectionTitle, Serif } from "./ui";

const REVIEWS = [
  {
    name: "Ahmed Raza",
    role: "CEO · Textile export house, Faisalabad",
    color: "#4285F4",
    when: "2 weeks ago",
    stars: 5,
    text: "Migrated 60 mailboxes from our old cPanel host over a single weekend — zero downtime, zero lost mail. Their engineer picked up my call at 2am when I panicked about MX records. Rare service in Pakistan.",
  },
  {
    name: "Fatima Khan",
    role: "HR Director · Software house, Lahore",
    color: "#EA4335",
    when: "a month ago",
    stars: 5,
    text: "We were quoted in dollars by two other resellers. gworkspace.pk billed us in PKR with a proper local invoice, onboarded 120 staff, and trained our HR team on Shared Drives. Flawless from day one.",
  },
  {
    name: "Bilal Mehmood",
    role: "Founder · E-commerce brand, Karachi",
    color: "#0F9D58",
    when: "3 weeks ago",
    stars: 5,
    text: "Honestly the best IT decision we made this year. Professional emails on our own domain instantly improved client trust. Setup took less than 48 hours exactly as promised.",
  },
  {
    name: "Ayesha Siddiqui",
    role: "Operations Manager · School network, Islamabad",
    color: "#F4B400",
    when: "2 months ago",
    stars: 4,
    text: "They moved our staff to Workspace for Education and ran training in Urdu for our non-technical teachers. Took a little follow-up to schedule the second session, but the support itself has been excellent.",
  },
  {
    name: "Usman Malik",
    role: "CTO · Fintech startup, Lahore",
    color: "#7248B9",
    when: "a month ago",
    stars: 5,
    text: "What sold me: I called at 11:45pm on a Sunday expecting a machine, and a human answered. Vault retention, 2FA enforcement, DLP — they configured our entire security posture in one visit.",
  },
  {
    name: "Hira Shah",
    role: "Managing Partner · Law firm, Lahore",
    color: "#00AC47",
    when: "3 months ago",
    stars: 5,
    text: "Confidentiality is everything in our practice. Their team set up document sharing policies and retention rules properly, then documented everything for our partners. Thoroughly professional outfit in Johar Town.",
  },
];

function Stars({ n, className = "h-3.5 w-3.5" }: { n: number; className?: string }) {
  return (
    <span className="flex gap-[2px]">
      {[...Array(5)].map((_, i) => (
        <Star
          key={i}
          strokeWidth={1.5}
          className={`${className} ${i < n ? "fill-g-yellow text-g-yellow" : "fill-ink/10 text-ink/10"}`}
        />
      ))}
    </span>
  );
}

export default function Reviews() {
  return (
    <section id="reviews" className="relative overflow-hidden bg-paper-2 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-12 lg:grid-cols-12 lg:gap-10">
          {/* score panel */}
          <div className="lg:col-span-4">
            <div className="lg:sticky lg:top-28">
              <Reveal>
                <SectionTag>Google Reviews</SectionTag>
              </Reveal>
              <Reveal delay={0.08}>
                <SectionTitle className="mt-6">
                  Rated <Serif>4.7</Serif> by the businesses we keep running.
                </SectionTitle>
              </Reveal>
              <Reveal delay={0.16}>
                <div className="mt-8 rounded-[1.75rem] border border-ink/8 bg-card p-8">
                  <div className="flex items-end gap-4">
                    <span className="font-display text-7xl font-medium leading-none tracking-tight text-ink">
                      4.7
                    </span>
                    <div className="pb-1.5">
                      <Stars n={5} className="h-4.5 w-4.5" />
                      <p className="mt-1.5 text-[13px] font-medium text-ink-soft">
                        86 verified Google reviews
                      </p>
                    </div>
                  </div>
                  <div className="mt-6 space-y-2">
                    {[
                      { s: 5, w: "82%" },
                      { s: 4, w: "12%" },
                      { s: 3, w: "4%" },
                    ].map((r) => (
                      <div key={r.s} className="flex items-center gap-3">
                        <span className="w-3 text-right text-[12px] font-semibold text-ink-soft">{r.s}</span>
                        <div className="h-2 flex-1 overflow-hidden rounded-full bg-ink/8">
                          <div className="h-full rounded-full bg-g-yellow" style={{ width: r.w }} />
                        </div>
                      </div>
                    ))}
                  </div>
                  <a
                    href="https://www.google.com/maps/search/Google+Workspace+Pakistan+Johar+Town+Lahore"
                    target="_blank"
                    rel="noreferrer"
                    className="group mt-7 flex items-center justify-between rounded-2xl border border-ink/10 bg-paper px-5 py-4 transition-all hover:border-ink/30"
                  >
                    <span className="flex items-center gap-3">
                      <GoogleG className="h-5 w-5" />
                      <span className="text-[13.5px] font-semibold text-ink">
                        Rate &amp; review us on Google
                      </span>
                    </span>
                    <ArrowUpRight className="h-4 w-4 text-ink-soft transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </a>
                </div>
              </Reveal>
            </div>
          </div>

          {/* review cards */}
          <div className="lg:col-span-8">
            <div className="grid gap-5 sm:grid-cols-2">
              {REVIEWS.map((r, i) => (
                <Reveal key={r.name} delay={i * 0.06} className={i % 2 === 1 ? "sm:mt-8" : ""}>
                  <figure className="flex h-full flex-col rounded-[1.5rem] border border-ink/8 bg-card p-7 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_24px_50px_-26px_rgba(11,18,32,0.28)]">
                    <div className="flex items-center justify-between">
                      <Stars n={r.stars} />
                      <GoogleG className="h-4.5 w-4.5 opacity-70" />
                    </div>
                    <blockquote className="mt-4 flex-1 text-[14.5px] leading-relaxed text-ink/80">
                      &ldquo;{r.text}&rdquo;
                    </blockquote>
                    <figcaption className="mt-6 flex items-center gap-3 border-t border-ink/6 pt-5">
                      <span
                        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-[14px] font-bold text-white"
                        style={{ background: r.color }}
                      >
                        {r.name[0]}
                      </span>
                      <div className="min-w-0">
                        <p className="truncate text-[13.5px] font-bold text-ink">{r.name}</p>
                        <p className="truncate text-[11.5px] text-ink-soft">{r.role}</p>
                      </div>
                      <span className="ml-auto shrink-0 text-[11px] text-ink-soft/70">{r.when}</span>
                    </figcaption>
                  </figure>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
