type IconProps = { className?: string };

/* ---------------- Brand mark: four Workspace dots ---------------- */
export function LogoMark({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <circle cx="7" cy="7" r="3.3" fill="#4285F4" />
      <circle cx="17" cy="7" r="3.3" fill="#EA4335" />
      <circle cx="7" cy="17" r="3.3" fill="#FBBC04" />
      <circle cx="17" cy="17" r="3.3" fill="#34A853" />
    </svg>
  );
}

/* ---------------- Google "G" ---------------- */
export function GoogleG({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <path
        fill="#4285F4"
        d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"
      />
      <path
        fill="#34A853"
        d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09C3.26 21.3 7.31 24 12 24z"
      />
      <path
        fill="#FBBC05"
        d="M5.27 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.98-3.09z"
      />
      <path
        fill="#EA4335"
        d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.98 3.09C6.22 6.86 8.87 4.75 12 4.75z"
      />
    </svg>
  );
}

/* ---------------- Workspace app glyphs (stylized) ---------------- */
export function GmailIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" aria-hidden>
      <path
        fill="#EA4335"
        d="M4.5 4h15A1.5 1.5 0 0 1 21 5.5v13a1.5 1.5 0 0 1-1.5 1.5h-15A1.5 1.5 0 0 1 3 18.5v-13A1.5 1.5 0 0 1 4.5 4Z"
      />
      <path
        d="M3.6 6.6 12 12.7l8.4-6.1M6 19.6V10.2M18 19.6v-9.4"
        stroke="#fff"
        strokeWidth="1.7"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export function DriveIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" strokeLinecap="round" aria-hidden>
      <path d="M12.2 4.9 4.6 18.2" stroke="#FBBC04" strokeWidth="3.1" />
      <path d="M12.2 4.9 19.8 18.2" stroke="#34A853" strokeWidth="3.1" />
      <path d="M4.8 18.6h14.9" stroke="#4285F4" strokeWidth="3.1" />
    </svg>
  );
}

export function MeetIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <rect x="2" y="6.3" width="13.4" height="11.4" rx="3" fill="#00AC47" />
      <path
        d="M15.4 10.7l5-3.3c.53-.34 1.1.03 1.1.62v7.96c0 .59-.57.96-1.1.62l-5-3.3z"
        fill="#00832D"
      />
    </svg>
  );
}

export function CalendarIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <rect x="3" y="5" width="18" height="15.6" rx="2.6" fill="#fff" stroke="#D2DCE8" strokeWidth="1.1" />
      <path d="M3 7.6A2.6 2.6 0 0 1 5.6 5h12.8A2.6 2.6 0 0 1 21 7.6V10H3z" fill="#4285F4" />
      <rect x="6.9" y="3" width="1.8" height="3.8" rx=".9" fill="#4285F4" />
      <rect x="15.3" y="3" width="1.8" height="3.8" rx=".9" fill="#4285F4" />
      <text x="12" y="17.9" textAnchor="middle" fontSize="7.2" fontWeight="700" fill="#334155">
        31
      </text>
    </svg>
  );
}

export function DocsIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <path
        fill="#4285F4"
        d="M6 2.5h7V8h5.5v12.5a1.5 1.5 0 0 1-1.5 1.5H6A1.5 1.5 0 0 1 4.5 20.5V4A1.5 1.5 0 0 1 6 2.5Z"
      />
      <path fill="#A8C7FA" d="M13 2.5 18.5 8H13z" />
      <g fill="#fff">
        <rect x="7" y="11" width="9" height="1.5" rx=".75" />
        <rect x="7" y="14" width="9" height="1.5" rx=".75" />
        <rect x="7" y="17" width="6" height="1.5" rx=".75" />
      </g>
    </svg>
  );
}

export function SheetsIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <path
        fill="#0F9D58"
        d="M6 2.5h7V8h5.5v12.5a1.5 1.5 0 0 1-1.5 1.5H6A1.5 1.5 0 0 1 4.5 20.5V4A1.5 1.5 0 0 1 6 2.5Z"
      />
      <path fill="#B7E1CD" d="M13 2.5 18.5 8H13z" />
      <rect x="7" y="11.5" width="10" height="7" rx="1" fill="#fff" />
      <path stroke="#0F9D58" strokeWidth="1" d="M10.4 11.5v7M13.8 11.5v7M7 14.8h10M7 17.2h10" />
    </svg>
  );
}

export function SlidesIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <path
        fill="#F4B400"
        d="M6 2.5h7V8h5.5v12.5a1.5 1.5 0 0 1-1.5 1.5H6A1.5 1.5 0 0 1 4.5 20.5V4A1.5 1.5 0 0 1 6 2.5Z"
      />
      <path fill="#FDE293" d="M13 2.5 18.5 8H13z" />
      <rect x="7" y="10.8" width="10" height="6.2" rx="1.2" fill="#fff" />
      <rect x="11.3" y="17.4" width="1.4" height="1.6" fill="#fff" />
      <rect x="9.2" y="18.9" width="5.6" height="1.1" rx=".55" fill="#fff" />
    </svg>
  );
}

export function ChatIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <path
        fill="#00AC47"
        d="M4 4.5h16A1.5 1.5 0 0 1 21.5 6v9a1.5 1.5 0 0 1-1.5 1.5H9.6L5 20.6v-4.1H4A1.5 1.5 0 0 1 2.5 15V6A1.5 1.5 0 0 1 4 4.5Z"
      />
      <g fill="#fff">
        <circle cx="7.8" cy="10.5" r="1.25" />
        <circle cx="12" cy="10.5" r="1.25" />
        <circle cx="16.2" cy="10.5" r="1.25" />
      </g>
    </svg>
  );
}

export function AdminIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <path fill="#4285F4" d="M12 2.3 19.6 4.8v6.1c0 4.7-3.1 8.8-7.6 10.8-4.5-2-7.6-6.1-7.6-10.8V4.8z" />
      <circle cx="12" cy="9.4" r="2.25" fill="#fff" />
      <path
        fill="#fff"
        d="M7.9 15.9c.7-2.3 2.3-3.5 4.1-3.5s3.4 1.2 4.1 3.5a.8.8 0 0 1-.76 1.05H8.66a.8.8 0 0 1-.76-1.05Z"
      />
    </svg>
  );
}

export function FormsIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <path
        fill="#7248B9"
        d="M6 2.5h7V8h5.5v12.5a1.5 1.5 0 0 1-1.5 1.5H6A1.5 1.5 0 0 1 4.5 20.5V4A1.5 1.5 0 0 1 6 2.5Z"
      />
      <path fill="#C4A7E8" d="M13 2.5 18.5 8H13z" />
      <g fill="#fff">
        <rect x="7" y="11" width="3" height="3" rx=".6" />
        <rect x="11.4" y="11.7" width="4.6" height="1.4" rx=".7" />
        <rect x="7" y="15.6" width="3" height="3" rx=".6" />
        <rect x="11.4" y="16.3" width="4.6" height="1.4" rx=".7" />
      </g>
    </svg>
  );
}

export function KeepIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <rect x="4" y="3" width="16" height="18" rx="2.5" fill="#FBBC04" />
      <circle cx="12" cy="10.3" r="3.2" fill="#fff" />
      <rect x="10.7" y="13" width="2.6" height="2.4" rx="1.1" fill="#fff" />
      <rect x="10.2" y="16.2" width="3.6" height="1.2" rx=".6" fill="#fff" />
    </svg>
  );
}

export function GeminiIcon({ className }: IconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden>
      <defs>
        <linearGradient id="gemini-grad" x1="3" y1="3" x2="21" y2="21" gradientUnits="userSpaceOnUse">
          <stop stopColor="#3E8FF5" />
          <stop offset="1" stopColor="#9B72CB" />
        </linearGradient>
      </defs>
      <path
        fill="url(#gemini-grad)"
        d="M12 1.8c.98 6.02 4.16 9.2 10.2 10.2-6.04.98-9.22 4.18-10.2 10.2-.98-6.02-4.16-9.2-10.2-10.2C7.84 11 11 7.82 12 1.8Z"
      />
    </svg>
  );
}
