import { Suspense } from "react";
import Navbar from "@/components/site/navbar";
import Hero from "@/components/site/hero";
import Suite from "@/components/site/suite";
import Services from "@/components/site/services";
import Pricing from "@/components/site/pricing";
import Reviews from "@/components/site/reviews";
import Faq from "@/components/site/faq";
import Contact from "@/components/site/contact";
import Footer from "@/components/site/footer";

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navbar />
      <Hero />
      <Suite />
      <Services />
      <Pricing />
      <Reviews />
      <Faq />
      <Suspense>
        <Contact />
      </Suspense>
      <Footer />
    </main>
  );
}
