import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/db";
import { leads } from "@/db/schema";

const LeadSchema = z.object({
  name: z.string().trim().min(2, "Name is too short").max(120),
  email: z.string().trim().email("Invalid email address").max(200),
  phone: z.string().trim().max(40).optional().or(z.literal("")),
  company: z.string().trim().max(160).optional().or(z.literal("")),
  plan: z.string().trim().max(80).optional().or(z.literal("")),
  message: z.string().trim().max(2000).optional().or(z.literal("")),
});

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const parsed = LeadSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { ok: false, error: "Please double-check your name and work email, then try again." },
        { status: 400 }
      );
    }

    const { name, email, phone, company, plan, message } = parsed.data;

    const [row] = await db
      .insert(leads)
      .values({
        name,
        email,
        phone: phone || null,
        company: company || null,
        plan: plan || null,
        message: message || null,
      })
      .returning({ id: leads.id });

    return NextResponse.json({ ok: true, id: row.id });
  } catch (err) {
    console.error("POST /api/leads failed:", err);
    return NextResponse.json(
      {
        ok: false,
        error: "Our form hiccuped — but we never close. Call or WhatsApp 0311 1222735 instead.",
      },
      { status: 500 }
    );
  }
}
