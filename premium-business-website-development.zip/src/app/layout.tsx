import type { Metadata } from "next";
import { Inter, Space_Grotesk, Instrument_Serif } from "next/font/google";
import "./globals.css";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const space = Space_Grotesk({ subsets: ["latin"], variable: "--font-space" });
const instrument = Instrument_Serif({
  subsets: ["latin"],
  weight: "400",
  style: ["normal", "italic"],
  variable: "--font-instrument",
});

export const metadata: Metadata = {
  title: "Google Workspace Pakistan — Business Apps & Collaboration Tools",
  description:
    "Google Workspace deployment, migration, training and 24/7 local support for Pakistani businesses. Rated 4.7 with 86 Google reviews. HQ in Johar Town, Lahore — serving Karachi, Islamabad & beyond.",
  keywords: [
    "Google Workspace Pakistan",
    "Google Workspace Lahore",
    "business email Pakistan",
    "gworkspace.pk",
    "Google Workspace reseller",
    "email migration Pakistan",
  ],
  openGraph: {
    title: "Google Workspace Pakistan — Business Apps & Collaboration Tools",
    description:
      "Setup, migration, training & 24/7 support for Google Workspace — billed in PKR, live in 48 hours. Rated 4.7 on Google.",
    type: "website",
    locale: "en_PK",
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" className={`${inter.variable} ${space.variable} ${instrument.variable}`}>
      <body>{children}</body>
    </html>
  );
}
